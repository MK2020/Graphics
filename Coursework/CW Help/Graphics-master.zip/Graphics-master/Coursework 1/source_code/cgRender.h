#ifndef _CG_RENDER_H
#define _CG_RENDER_H

#include <GL/glut.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <GL/glut.h>
#include <stdlib.h>


using namespace std;

#include <fstream>
#include <iostream>

#endif
